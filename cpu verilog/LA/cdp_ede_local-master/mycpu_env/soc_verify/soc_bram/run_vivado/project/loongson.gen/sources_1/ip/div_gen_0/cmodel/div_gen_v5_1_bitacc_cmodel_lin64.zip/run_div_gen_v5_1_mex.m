% (c) Copyright 2015, 2023 Advanced Micro Devices, Inc. All rights reserved.
%
% This file contains confidential and proprietary information
% of AMD and is protected under U.S. and international copyright
% and other intellectual property laws.
%
% DISCLAIMER
% This disclaimer is not a license and does not grant any
% rights to the materials distributed herewith. Except as
% otherwise provided in a valid license issued to you by
% AMD, and to the maximum extent permitted by applicable
% law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
% WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
% AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
% BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
% INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
% (2) AMD shall not be liable (whether in contract or tort,
% including negligence, or under any other theory of
% liability) for any loss or damage of any kind or nature
% related to, arising under or in connection with these
% materials, including for any direct, or any indirect,
% special, incidental, or consequential loss or damage
% (including loss of data, profits, goodwill, or any type of
% loss or damage suffered as a result of any action brought
% by a third party) even if such damage or loss was
% reasonably foreseeable or AMD had been advised of the
% possibility of the same.
%
% CRITICAL APPLICATIONS
% AMD products are not designed or intended to be fail-
% safe, or for use in any application requiring fail-safe
% performance, such as life-support or safety devices or
% systems, Class III medical devices, nuclear facilities,
% applications related to the deployment of airbags, or any
% other applications that could lead to death, personal
% injury, or severe property or environmental damage
% (individually and collectively, "Critical
% Applications"). Customer assumes the sole risk and
% liability of any use of AMD products in Critical
% Applications, subject only to applicable laws and
% regulations governing limitations on product liability.
%
% THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
% PART OF THIS FILE AT ALL TIMES.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Run some basic tests demonstrating the div_gen_v5_1_bitacc MEX function
%   run_div_gen_v5_1_bitacc_mex()
%
% Configuration parameters are:
  %   algorithm_type, divisor_width, dividend_width, operand_sign, remainder_type, fractional_width, clocks_per_division. Consult div_gen_v5_1_bitacc_cmodel.h for applicable values.
function run_div_gen_v5_1_mex(varargin)
  % Constants
  data_samples = 10;
  interactive = 0; #Set this to one for interactive mode where user keypress is required between demonstrations.

  %for auto tests
  passes = 0;
  errors = 0;

  % Create default divider
  disp('---------------------------------------------------------------------');
  disp('INFO: Create default divider');
  disp('---------------------------------------------------------------------');
  if (interactive==1) disp('Press any key to continue...'); pause; end;
  div1    = div_gen_v5_1_bitacc()
  config1 = get_configuration(div1);

  % Create an input data vector
  %   - Scaled to match the default models data format; Fix16_0
  disp('INFO: Generate input data...');
  divisor_in = [1:1:data_samples]
  dividend_in = horzcat( [8:8:data_samples*4],[10:10:data_samples*5] )

  % Filter data
  disp('INFO: Result...');
  [quotient_out] = divide(div1,dividend_in,divisor_in)

  if (quotient_out == [8 8 8 8 8 1 2 3 4 5]) passes = passes+1; else errors = errors+1; end;
  if (interactive==1) disp('Press any key to continue...'); pause; end;

  % Create remainder output divider
  disp('---------------------------------------------------------------------');
  disp('INFO: Create divider with remainder output');
  disp('---------------------------------------------------------------------');
  div2    = div_gen_v5_1_bitacc('remainder_type', 0);
  config2 = get_configuration(div2)

  % Create an input data vector
  %   - Scaled to match the default models data format; Fix16_0
  disp('INFO: Generate input data...');
  divisor_in = [1:1:data_samples]
  dividend_in = horzcat( [8:8:data_samples*4], [10:10:data_samples*5] )

  % Filter data
  disp('INFO: Result...');
  [quotient_out remainder_out] = divide(div2,dividend_in,divisor_in)

  if (quotient_out == [8 8 8 8 8 1 2 3 4 5]) passes = passes+1; else errors = errors+1; end;
  if (remainder_out == [0 0 0 0 0 4 6 6 4 0]) passes = passes+1; else errors = errors+1; end;
  if (interactive==1) disp('Press any key to continue...'); pause; end;

  % Create fractional output divider
  disp('---------------------------------------------------------------------');
  disp('INFO: Create divider with fractional output');
  disp('---------------------------------------------------------------------');
  div3    = div_gen_v5_1_bitacc('remainder_type', 1);
  config3 = get_configuration(div3)

  % Create an input data vector
  %   - Scaled to match the default models data format; Fix16_0
  disp('INFO: Generate input data...');
  divisor_in = [1:1:data_samples]
  dividend_in = horzcat( [8:8:data_samples*4], [10:10:data_samples*5] )

  disp('INFO: Result...');
  [quotient_out] = divide(div3,dividend_in,divisor_in)

  disp('For the Radix2 divider with fractional output the sign');
  disp('bit is repeated in the fractional part of the result, hence the');
  disp('fractional part can appear to be 1/2 of that expected.');
  disp('Hence, the fractional part, reinterpreted becomes');
  [fractional] = (quotient_out-floor(quotient_out))*2

  if ((quotient_out(6)) > 1 && (quotient_out(6)<1.5) ) passes = passes+1; else errors = errors+1; end;

  if (interactive==1) disp('Press any key to continue...'); pause; end;

  % Create High Radix divider
  disp('---------------------------------------------------------------------');
  disp('INFO: Create High Radix divider ');
  disp('---------------------------------------------------------------------');
  div4    = div_gen_v5_1_bitacc('algorithm_type', 3, ...
                                'remainder_type', 1 );
  config4 = get_configuration(div4)

  % Create an input data vector
  %   - Scaled to match the default models data format; Fix16_0
  disp('INFO: Generate input data...');
  divisor_in = [1:1:data_samples]
  dividend_in = horzcat( [8:8:data_samples*4], [10:10:data_samples*5] )
  divisor_in(5) = 0

  disp('INFO: Result...');
  [quotient_out div_by_zero] = divide(div4,dividend_in,divisor_in)

  if (div_by_zero(5) == 1) passes=passes+1; else errors = errors+1; end;
  if (interactive==1) disp('Press any key to continue...'); pause; end;

  if ((errors == 0) && (passes>0)) disp('Test completed successfully'); end;

end

