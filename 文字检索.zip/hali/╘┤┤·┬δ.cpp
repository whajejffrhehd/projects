#include<iostream>
#include<string>
#include<fstream>
#include<stdlib.h>
#include<time.h> 
using namespace std;
bool daxie(string a)
{
	if (a[0] == 'C')
		return true;
	return false;
}

string name, temp, he[20000];
int chapter;
char a[10000];
int index = 0, page = 1, ix;
void magic(string prename, string strname)
{
	page = 1;
	chapter = 1;
	name = strname;
	ifstream infile;
	string txtname = prename + ".txt";
	infile.open(txtname.c_str());
	if (!infile)
	{
		cerr << "File could not be open!" << endl;
		abort();
	}
	while (infile.getline(a, 10000))
	{
		temp = a;
		if (temp[0] > '0'&&temp[0] <= '9')
			page++;
		if (temp.find("Chapter") != string::npos&&daxie(temp) || temp.find("CHAPTER") != string::npos&&daxie(temp))
		{
			chapter++;
		}
		if (temp.find(name) != string::npos)
		{
			ix = -1;
			while (temp.find(name, ix + 1) != string::npos)
			{
				ix = temp.find(name, ix + 1);
				index++;
				cout << index  << "		" << name << '\t'<< "		" << page << '\t' <<"	"<< chapter << '\t'  << prename<< '\t' << endl;
				he[index] = temp;
			}
		}
	}
}
int main()
{cout<<"������Ҫ����������"<<endl;
	getline(cin, name);
clock_t startTime,endTime;  startTime = clock();   
	cout << "���		���� / ����\t	ҳ��\t	�½�\t 	����\t" << endl;
	magic("D:\\hali\\J.K. Rowling - HP 0 - Harry Potter Prequel.txt", name);
	magic("D:\\hali\\J.K. Rowling - Quidditch Through the Ages.txt", name);
	magic("D:\\hali\\J.K. Rowling - The Tales of Beedle the Bard.txt", name);
	magic("D:\\hali\\J.K. Rowling - HP 3 - Harry Potter and the Prisoner of Azkaban.txt", name);
	magic("D:\\hali\\J.K. Rowling - HP 4 - Harry Potter and the Goblet of Fire.txt", name);
	magic("D:\\hali\\J.K. Rowling - HP 6 - Harry Potter and the Half-Blood Prince.txt", name);
	magic("D:\\hali\\HP7--Harry_Potter_and_the_Deathly_Hallows_Book_7_.txt", name);
	magic("D:\\hali\\HP2--Harry_Potter_and_the_Chamber_of_Secrets_Book_2_.txt", name);

endTime = clock();  cout << '\n'<<"������ϣ� " <<(double)(endTime - startTime)/CLOCKS_PER_SEC << "s" << endl;   
	int i;
	cout<<"��ѯ�������Ӧ�ľ���"<<endl; 
	cin >> i;
	cout << he[i - 1] << he[i] << he[i + 1] << endl;
	system("pause");
	return 0;
}


